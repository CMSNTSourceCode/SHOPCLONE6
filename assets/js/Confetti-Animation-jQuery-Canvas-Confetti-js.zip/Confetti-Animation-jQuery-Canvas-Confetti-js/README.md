# jquery.confetti.js
A jQuery plugin to show confetti.

JsFiddle inspiration (not a jQuery plugin): http://jsfiddle.net/Javalsu/vxP5q/743/embedded/result/

Plnker Demo of this Repo:  http://plnkr.co/edit/DMHO91

Start:
------

    $.confetti.start();

or

    <button id="startConfetti"></button>

Stop:
-----

    $.confetti.stop();

or

    <button id="stopConfetti"></button>

Restart:
--------

    $.confetti.restart();

or

    <button id="restartConfetti"></button>
